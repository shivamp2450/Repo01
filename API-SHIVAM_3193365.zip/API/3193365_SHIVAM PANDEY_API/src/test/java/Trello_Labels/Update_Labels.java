package Trello_Labels;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import Trello_Cards.Create_Card;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Update_Labels {
	public static String ApiKey="f876462aba1677b8d1674152b3024459";
	public static String tokenKey="8a0b93ed86e90ff2eee8d6fb0516221da10682c72ce50756db89359a9c39d22a\r\n"
			+ "";
	public static String ID;
	public static Logger log = LogManager.getLogger(Create_Labels.class.getName());
	@Test(priority=11)
	static void  UpdatingLabels() {
		log.info("updating a List");
		RestAssured.baseURI="https://api.trello.com";
		//Creating a request
		RequestSpecification httpreq = RestAssured.given().header("Accept", "application/json").header("Content-Type","application/json").queryParam("name", "Shivam")
				.queryParam("id", Create_Labels.ID).queryParam("name", "tayal")
				  .queryParam("key", ApiKey)
				  .queryParam("token", tokenKey);
		
		Response res = httpreq.when().put(Create_Labels.ID);

		res.prettyPeek();
}
}