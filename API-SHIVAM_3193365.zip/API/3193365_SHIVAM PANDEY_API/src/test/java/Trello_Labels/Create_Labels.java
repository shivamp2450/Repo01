package Trello_Labels;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import Trello_Cards.Create_Card;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Create_Labels {
	public static String ApiKey="f876462aba1677b8d1674152b3024459";
	public static String tokenKey="8a0b93ed86e90ff2eee8d6fb0516221da10682c72ce50756db89359a9c39d22a";
	public static String ID;
	public static Logger log = LogManager.getLogger(Create_Labels.class.getName());
	@Test(priority=9)
	static void  CreatingLabels() {
		log.info("creating a List");
		RestAssured.baseURI="https://api.trello.com";
		//Creating a request
		RequestSpecification httpreq = RestAssured.given().header("Accept", "application/json").header("Content-Type","application/json").queryParam("name", "Shivam")
				.queryParam("name", "Shivam").queryParam("color", "red").queryParam("idBoard", "6326d615b4d37702daa546f0")
				  .queryParam("key", ApiKey)
				  .queryParam("token", tokenKey);
		
		Response res = httpreq.when().post("/1/labels/").then().assertThat().statusCode(200).extract().response();

		res.prettyPeek();
		String str=res.asPrettyString();
		JsonPath x=new JsonPath(str);
		ID =x.get("id").toString();
		System.out.println(ID);
		Assert.assertEquals(x.get("name"),"Shivam");
		System.out.println("Assertion successfull");
	
		
}
}