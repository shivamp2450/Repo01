package Trello_Cards;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;


import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Update_Card{
	public static Logger log = LogManager.getLogger(Create_Card.class.getName());
	public static String ApiKey="f876462aba1677b8d1674152b3024459";
	public static String tokenKey="8a0b93ed86e90ff2eee8d6fb0516221da10682c72ce50756db89359a9c39d22a";
	@Test(priority=6)
	static void UpdatingCards(){
		log.info("updating a card");
		RestAssured.baseURI="https://api.trello.com/1/cards/";
		//Creating a request
		RequestSpecification httpreq = RestAssured.given().header("Accept", "application/json").header("Content-Type","application/json").queryParam("name", "Shub")
				  .queryParam("idList", "632701fd18a3960265e7b762")
				  .queryParam("name", "hello world")
				  .queryParam("key", ApiKey)
				  .queryParam("token", tokenKey);
		
		Response res = httpreq.when().put(Create_Card.ID);

		res.prettyPeek();
		
	}

}




