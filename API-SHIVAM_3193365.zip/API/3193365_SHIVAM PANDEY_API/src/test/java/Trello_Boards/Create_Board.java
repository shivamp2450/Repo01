package Trello_Boards;

import org.apache.logging.log4j.LogManager;
import org.testng.Assert;
import org.testng.annotations.Test;

import org.apache.logging.log4j.Logger;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;




public class Create_Board {
	public static String ID;
	public static Logger log = LogManager.getLogger(Create_Board.class.getName());
	@Test
	(priority=0)
	public static void CreatingBoard() {
		log.info("creating a board");
		RestAssured.baseURI="https://api.trello.com";
		//Creating a request
		RequestSpecification httpreq = RestAssured.given().queryParam("name", "Shivam").queryParam("key","f876462aba1677b8d1674152b3024459")
				.queryParam("token","8a0b93ed86e90ff2eee8d6fb0516221da10682c72ce50756db89359a9c39d22a").header("Content-Type","application/json");

		//Defining the parameters
		Response res = httpreq.when().post("/1/boards/").then().assertThat().statusCode(200).extract().response();
		

		res.prettyPeek();
		String str=res.asPrettyString();
		JsonPath x=new JsonPath(str);
		ID =x.get("id").toString();
		System.out.println(ID);
		Assert.assertEquals(x.get("name"),"Shivam");
		System.out.println("Assertion successfull");
		
	}
}
